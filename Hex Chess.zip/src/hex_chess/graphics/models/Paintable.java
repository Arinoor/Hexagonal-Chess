package hex_chess.graphics.models;

import java.awt.*;

public interface Paintable {
    void paint(Graphics2D g2);
}
