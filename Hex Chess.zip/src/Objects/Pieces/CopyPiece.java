package Objects.Pieces;

public interface CopyPiece {
    Piece getCopy();
}
